I have used python3 to do this assignment and python libraries "re" and "nltk" are to be preinstalled on the system this code is run using commands:

1) pip3 install re

2) pip install --user -U nltk

To run the code, simply run the following command:

python3 HM1Main.py


There was a slight mistake in Path.py file which I have rectified and the new Path.py file is also enclosed in the ZIP submission.

If run on my macbook pro, processing all the text type documents takes 1 hour 5 minutes while processing all the web type documents takes 23 minutes. Waiting for around 1.5 hours will definitely generate all the relevant result files.