# address of target corpus docset.trectext.
DataDir = "data//input//input_data.txt"

# address of stopword list.
StopwordDir="data//input//stopword.txt"

# uncompleted address of preprocessed corpus.
ResultHM1="data//result.txt"

# address of generated Text index file.
IndexDir="data//index//"

# address of the topics file - added by Om.
TopicDir="data//input//"

# address of the id to filename mappings file.
FilesDictDir="data//input//dict.txt"